import numpy as np
import torch
from cst import *
from scipy.io import loadmat
from rombo.test_problems.test_problems import InverseAirfoil, EnvModelFunction
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')


# Setting data type and device for Pytorch based libraries
tkwargs = {
    "dtype": torch.float,
    "device": torch.device("cuda:0" if torch.cuda.is_available() else "cpu"),
}

n_trials = 5
n_init = 50
n_iterations = 75
mc_samples = 32
objective = EnvModelFunction(input_dim=13, output_dim=1024, normalized=True)

boei_objectives = np.zeros((n_trials, n_iterations))
bologei_objectives = np.zeros((n_trials, n_iterations))
romboei_objectives = np.zeros((n_trials, n_iterations))
rombologei_objectives = np.zeros((n_trials, n_iterations))
podboei_objectives = np.zeros((n_trials, n_iterations))
podbologei_objectives = np.zeros((n_trials, n_iterations))

boei_dvs = np.zeros((n_trials, n_iterations))
bologei_dvs = np.zeros((n_trials, n_iterations))
romboei_dvs = np.zeros((n_trials, n_iterations))
rombologei_dvs = np.zeros((n_trials, n_iterations))
podboei_dvs = np.zeros((n_trials, n_iterations))
podbologei_dvs = np.zeros((n_trials, n_iterations))

boei_t = np.zeros((n_trials, n_iterations))
bologei_t = np.zeros((n_trials, n_iterations))
romboei_t = np.zeros((n_trials, n_iterations))
rombologei_t = np.zeros((n_trials, n_iterations))
podboei_t = np.zeros((n_trials, n_iterations))
podbologei_t = np.zeros((n_trials, n_iterations))

boei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
bologei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
romboei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
rombologei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
podboei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
podbologei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))

bologei_ydoe = np.zeros((n_trials, n_iterations+n_init, 500))
boei_ydoe = np.zeros((n_trials, n_iterations+n_init, 500))
romboei_ydoe = np.zeros((n_trials, n_iterations+n_init, 500))
rombologei_ydoe = np.zeros((n_trials, n_iterations+n_init, 500))
podbologei_ydoe = np.zeros((n_trials, n_iterations+n_init, 500))

for trial in range(5):

    data = loadmat('./airfoil/rombo_results_negishi/BO_results/airfoil_inverse_design_optimizer2_{}.mat'.format(trial+1))
    bologei_data = data['BO_LOGEI']
    bologei_objectives[trial] = bologei_data['objectives'][0][0]
    bologei_t[trial] = bologei_data['time'][0][0]
    bologei_dvs[trial] = bologei_data['design'][0][0]
    bologei_doe[trial] = bologei_data['xdoe'][0][0]
    bologei_ydoe[trial] = bologei_data['ydoe'][0][0]

for trial in range(5):

    data = loadmat('./airfoil/rombo_results_negishi/SAASBO_results/airfoil_inverse_design_saasbo_optimizer2_{}.mat'.format(trial+1))
    boei_data = data['BO_LOGEI']
    boei_objectives[trial] = boei_data['objectives'][0][0]
    boei_t[trial] = boei_data['time'][0][0]
    boei_dvs[trial] = boei_data['design'][0][0]
    boei_doe[trial] = boei_data['xdoe'][0][0]
    boei_ydoe[trial] = boei_data['ydoe'][0][0]

for trial in range(5):

    data = loadmat('./airfoil/rombo_results_negishi/ROMBO/airfoil_inverse_design_optimizer4_{}.mat'.format(trial+1))
    rombologei_data = data['ROMBO_LOGEI']
    rombologei_objectives[trial] = rombologei_data['objectives'][0][0]
    rombologei_t[trial] = rombologei_data['time'][0][0]
    rombologei_dvs[trial] = rombologei_data['design'][0][0]
    rombologei_doe[trial] = rombologei_data['xdoe'][0][0]
    rombologei_ydoe[trial] = rombologei_data['ydoe'][0][0]

for trial in range(5):

    data = loadmat('./airfoil/rombo_results_negishi/ROMSAASBO/airfoil_inverse_design_saasbo_optimizer4_{}.mat'.format(trial+1))
    romboei_data = data['ROMBO_LOGEI']
    romboei_objectives[trial] = romboei_data['objectives'][0][0]
    romboei_t[trial] = romboei_data['time'][0][0]
    romboei_dvs[trial] = romboei_data['design'][0][0]
    romboei_doe[trial] = romboei_data['xdoe'][0][0]
    romboei_ydoe[trial] = romboei_data['ydoe'][0][0]

for trial in range(5):

    data = loadmat('./airfoil/rombo_results_negishi/POD_results/airfoil_inverse_design_POD_trial{}.mat'.format(trial+1))
    podbologei_data = data['ROMBO_LOGEI']

    podbologei_objectives[trial] = podbologei_data['objectives'][0][0]
    podbologei_t[trial] = podbologei_data['time'][0][0]
    podbologei_dvs[trial] = podbologei_data['design'][0][0]
    podbologei_doe[trial] = podbologei_data['xdoe'][0][0]
    podbologei_ydoe[trial] = podbologei_data['ydoe'][0][0]
        
#data_list = [bologei_objectives, rombologei_objectives, romboei_objectives, podbologei_objectives]
data_list = [bologei_t, rombologei_t,  romboei_t, podbologei_t]

# Finding the best trial and corresponding design variables
trial_idx = [bologei_objectives[:,-1].argmax(), boei_objectives[:,-1].argmax(), romboei_objectives[:,-1].argmax(), rombologei_objectives[:,-1].argmax(),
            podbologei_objectives[:,-1].argmax()]

# Plotting the contours of the function
x_list = [bologei_dvs[trial_idx[0]][-1], boei_dvs[trial_idx[1]][-1], romboei_dvs[trial_idx[2]][-1], rombologei_dvs[trial_idx[3]][-1], podbologei_dvs[trial_idx[4]][-1]]
x1_list = [bologei_doe[trial_idx[0]][int(x_list[0])], boei_doe[trial_idx[1]][int(x_list[1])], romboei_doe[trial_idx[2]][int(x_list[2])], rombologei_doe[trial_idx[3]][int(x_list[3])], 
        podbologei_doe[trial_idx[4]][int(x_list[4])]]
y_list = [romboei_ydoe[trial_idx[2]][int(x_list[2])], rombologei_ydoe[trial_idx[3]][int(x_list[3])], 
        podbologei_ydoe[trial_idx[4]][int(x_list[4])]]

coords = readCoordFile("./rae2822.dat")
DVGeo = CST("./rae2822.dat", numCST=6)

# Target pressure distribution
gbo_data = loadmat('./GBO_results.mat')
gbo_cp = gbo_data['Pressure_Dist']
gbo_dvs = gbo_data['design_var']

rae2822_data = loadmat('./RAE2822_results.mat')
rae2822_cp = rae2822_data['fieldData']['CoefPressure']

bo_data = loadmat('./BO_results.mat')
bo_cp = bo_data['fieldData']['CoefPressure']

saasbo_data = loadmat('./SAASBO_results.mat')
saasbo_cp = saasbo_data['fieldData']['CoefPressure']

y_list = [bo_cp[0][0][0], saasbo_cp[0][0][0], romboei_ydoe[trial_idx[2]][int(x_list[2])], rombologei_ydoe[trial_idx[3]][int(x_list[3])], 
        podbologei_ydoe[trial_idx[4]][int(x_list[4])]]

keys = ["upper", "lower"]

# Defining bounds of the sampling problem
lowerBounds = np.array([1.5])
upperBounds = np.array([3.5])
keys = ["upper", "lower"]
defaultDV = {"upper": DVGeo.upperCST, "lower": DVGeo.lowerCST}
for key in keys:
    coeff = defaultDV[key] # get the fitted CST coeff
    if key == "upper":
        dv_min = coeff - 0.30*coeff
        dv_max = coeff + 0.30*coeff
    else:
        dv_min = coeff - 0.30*coeff
        dv_max = coeff + 0.30*coeff

    for i in range(len(coeff)):
        lb = min([dv_min[i],dv_max[i]])
        ub = max([dv_min[i],dv_max[i]])
        lowerBounds = np.append(lowerBounds, lb)
        upperBounds = np.append(upperBounds, ub)

x1_list = [X*(upperBounds-lowerBounds)+lowerBounds for X in x1_list]
coords = readCoordFile('./rae2822.dat')
x_2822 = coords[:,0]
y_2822 = coords[:,1]
plt.rcParams['font.size'] = 11
fig, ax = plt.subplots()
upper_gbo = DVGeo.computeCSTCoordinates(x_2822, gbo_dvs[0][0][1][0], 0.5, 1.0, 0.0)
lower_gbo = DVGeo.computeCSTCoordinates(x_2822, gbo_dvs[0][0][2][0], 0.5, 1.0, 0.0)
color_list = ['darkorange','teal','red','blue','maroon']
label_list = ['BO+Log EI','SAASBO+Log EI','SAAS+ROMBO+Log EI','ROMBO+Log EI','PODBO+Log EI']
for i in range(len(x1_list)):
    upper_coords = DVGeo.computeCSTCoordinates(x_2822, x1_list[i][1:7], 0.5, 1.0, 0.0)
    lower_coords = DVGeo.computeCSTCoordinates(x_2822, x1_list[i][7:], 0.5, 1.0, 0.0)
    ax.plot(x_2822, upper_coords, color_list[i], label=label_list[i],linewidth=1.5)
    ax.plot(x_2822, lower_coords, color_list[i],linewidth=1.5)
ax.plot(x_2822, y_2822, 'k--', label = 'RAE2822')
# ax.grid()
ax.plot(x_2822, upper_gbo, 'g--', label='Target',linewidth=2.5)
ax.plot(x_2822, lower_gbo, 'g--', linewidth=2.5)
ax.legend(bbox_to_anchor=(0.5, 1.0), loc='lower center', ncol=3)
ax.set_xlabel('x/c')
ax.set_ylabel('y/c')
ax.set_aspect(6)
plt.tight_layout()
plt.savefig('airfoil_shapes.pdf')
plt.show()

fig, ax = plt.subplots()
upper_gbo = DVGeo.computeCSTCoordinates(x_2822, gbo_dvs[0][0][1][0], 0.5, 1.0, 0.0)
lower_gbo = DVGeo.computeCSTCoordinates(x_2822, gbo_dvs[0][0][2][0], 0.5, 1.0, 0.0)
ax.plot(x_2822, upper_gbo, 'g--', label='Target',linewidth=1.0)
ax.plot(x_2822, lower_gbo, 'g--',linewidth=1.0)
ax.plot(x_2822, y_2822, 'k--', label = 'RAE2822')
lower_1 = DVGeo.computeCSTCoordinates(x_2822, lowerBounds[1:7], 0.5, 1.0, 0.0)
lower_2 = DVGeo.computeCSTCoordinates(x_2822, lowerBounds[7:], 0.5, 1.0, 0.0)
upper_1 = DVGeo.computeCSTCoordinates(x_2822, upperBounds[1:7], 0.5, 1.0, 0.0)
upper_2 = DVGeo.computeCSTCoordinates(x_2822, upperBounds[7:], 0.5, 1.0, 0.0)
ax.fill_between(x_2822, lower_1, upper_1, color='cornflowerblue', alpha = 0.3, label = 'Design Space')
#ax.fill_between(x_2822, lower_2, upper_2, color='cornflowerblue', alpha=0.3)
# ax.grid()
ax.legend(bbox_to_anchor=(0.5, 1.0), loc='lower center', ncol=3)
ax.set_xlabel('x/c')
ax.set_ylabel('y/c')
ax.set_aspect(2)
ax.set_ylim([-0.10, 0.10])
plt.tight_layout()
plt.savefig('airfoil_design_space.pdf')
plt.show()
    
fig, ax = plt.subplots()
ax.plot(x_2822[:500], rae2822_cp[0][0][0], 'k--', label='RAE2822', linewidth=2)
for i in range(len(y_list)):
    ax.plot(x_2822[:500], y_list[i], color_list[i], label=label_list[i], linewidth=2)
ax.plot(x_2822[:500], gbo_cp[0], 'g--', label='Target', linewidth=2.5)
ax.set_xlabel('x/c')
ax.set_ylabel('$C_p$')
# ax.set_aspect(8)
ax.invert_yaxis()
ax.grid()
ax.legend(bbox_to_anchor=(0.5, 1.0), loc='lower center', ncol=3)
plt.tight_layout()
plt.savefig('pressures.pdf')
plt.show()


