import numpy as np
import torch
from scipy.io import loadmat
from rombo.test_problems.test_problems import InverseAirfoil
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# Setting data type and device for Pytorch based libraries
tkwargs = {
    "dtype": torch.float,
    "device": torch.device("cuda:0" if torch.cuda.is_available() else "cpu"),
}

n_trials = 5
n_init = 50
n_iterations = 75
mc_samples = 32
#objective = EnvModelFunction(input_dim=15, output_dim=1024, normalized=True)

boei_objectives = np.zeros((n_trials, n_iterations))
bologei_objectives = np.zeros((n_trials, n_iterations))
romboei_objectives = np.zeros((n_trials, n_iterations))
rombologei_objectives = np.zeros((n_trials, n_iterations))
podboei_objectives = np.zeros((n_trials, n_iterations))
podbologei_objectives = np.zeros((n_trials, n_iterations))

boei_dvs = np.zeros((n_trials, n_iterations))
bologei_dvs = np.zeros((n_trials, n_iterations))
romboei_dvs = np.zeros((n_trials, n_iterations))
rombologei_dvs = np.zeros((n_trials, n_iterations))
podboei_dvs = np.zeros((n_trials, n_iterations))
podbologei_dvs = np.zeros((n_trials, n_iterations))

boei_t = np.zeros((n_trials, n_iterations))
bologei_t = np.zeros((n_trials, n_iterations))
romboei_t = np.zeros((n_trials, n_iterations))
rombologei_t = np.zeros((n_trials, n_iterations))
podboei_t = np.zeros((n_trials, n_iterations))
podbologei_t = np.zeros((n_trials, n_iterations))

# boei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
# bologei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
# romboei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
# rombologei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
# podboei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
# podbologei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))

for trial in range(5):

    data = loadmat('./rombo_results_negishi/BO_results/airfoil_inverse_design_optimizer2_{}.mat'.format(trial+1))
    bologei_data = data['BO_LOGEI']
    bologei_objectives[trial] = bologei_data['objectives'][0][0]
    bologei_t[trial] = bologei_data['time'][0][0]
    bologei_dvs[trial] = bologei_data['design'][0][0]
    #bologei_doe[trial] = bologei_data['doe'][0][0][0]

for trial in range(5):

    data = loadmat('./rombo_results_negishi/SAASBO_results/airfoil_inverse_design_saasbo_optimizer2_{}.mat'.format(trial+1))
    boei_data = data['BO_LOGEI']
    boei_objectives[trial] = boei_data['objectives'][0][0]
    boei_t[trial] = boei_data['time'][0][0]
    boei_dvs[trial] = boei_data['design'][0][0]
    #bologei_doe[trial] = bologei_data['doe'][0][0][0]
    
for trial in range(5):

    data = loadmat('./rombo_results_negishi/ROMBO/airfoil_inverse_design_optimizer4_{}.mat'.format(trial+1))
    rombologei_data = data['ROMBO_LOGEI']
    rombologei_objectives[trial] = rombologei_data['objectives'][0][0]
    rombologei_t[trial] = rombologei_data['time'][0][0]
    rombologei_dvs[trial] = rombologei_data['design'][0][0]
    #rombologei_doe[trial] = rombologei_data['doe'][0][0][0]

for trial in range(5):

    data = loadmat('./rombo_results_negishi/ROMSAASBO/airfoil_inverse_design_saasbo_optimizer4_{}.mat'.format(trial+1))
    romboei_data = data['ROMBO_LOGEI']
    romboei_objectives[trial] = romboei_data['objectives'][0][0]
    romboei_t[trial] = romboei_data['time'][0][0]
    romboei_dvs[trial] = romboei_data['design'][0][0]
    #romboei_doe[trial] = rombologei_data['doe'][0][0][0]

for trial in range(5):

    data = loadmat('./rombo_results_negishi/POD_results/airfoil_inverse_design_POD_trial{}.mat'.format(trial+1))
    rombologei_data = data['ROMBO_LOGEI']

    podbologei_objectives[trial] = rombologei_data['objectives'][0][0]
    podbologei_t[trial] = rombologei_data['time'][0][0]
    podbologei_dvs[trial] = rombologei_data['design'][0][0]
    #podbologei_doe[trial] = rombologei_data['doe'][0][0][0]
        
data_list = [bologei_objectives, boei_objectives, rombologei_objectives, romboei_objectives, podbologei_objectives]
#data_list = [bologei_t, boei_t, rombologei_t,  romboei_t, podbologei_t]

# Plotting the objective function history
plt.rcParams['font.size'] = 13
fig, ax = plt.subplots()
iter = np.arange(1,76,1)
#iter = np.arange(1,26,1)
color_list = ['darkorange','teal','red','blue','maroon']
labels = ['BO+Log EI','SAASBO+Log EI','ROMBO+Log EI','SAAS+ROMBO+Log EI','PODBO+Log EI']
fill_color = ['darkorange','teal','red','blue','maroon']
i = 0
for data in data_list:
    
    # Calculating statistics of objectives and design variables for optimization
    objectives = np.log10(-data)
    mean_objectives = objectives.mean(axis = 0)
    objectives_std = objectives.std(axis = 0)/np.sqrt(5)

    lower_objectives = mean_objectives - objectives_std
    upper_objectives = mean_objectives + objectives_std
    
    #lower_objectives[lower_objectives < 1e-3] = 1e-1
    
    ax.errorbar(iter, mean_objectives, yerr=1.96*objectives_std,
                    color=color_list[i],     # Line color
                    ecolor=fill_color[i],    # Error bar color
                    capsize=3, capthick=1,   # Cap style
                    alpha=0.5,
                    label=labels[i], linewidth=3)
    #plt.fill_between(iter, lower_objectives, upper_objectives, color = fill_color[i], alpha=0.3, zorder=100)
    i+=1

ax.grid()
ax.legend(bbox_to_anchor=(0.5, 1.0), loc='lower center', ncol=2)
ax.set_xlabel('Iteration')
#ax.set_ylabel('Log($f_c^*$)')
ax.set_ylabel('Time Cost (s)')
ax.set_xlim([1,75])
#ax.set_yscale('log')
#ax.set_ylim([-1.3,3.0])
#ax.set_aspect(0.5)
plt.tight_layout()
#plt.savefig('airfoil_time.pdf')
plt.show()

# Printing the best objective values
print("Statistics of objective values")
print("Name: Average Best Worst Median") 
for i in range(5):
    objectives = np.log10(-data_list[i]) #np.log10(-data)
    mean_objectives = objectives.mean(axis = 0)
    median_objectives = np.median(objectives, axis = 0) # Check calculation of the median and standard error
    objectives_std = objectives.std(axis = 0)/np.sqrt(n_trials)
    print(labels[i],':',mean_objectives[-1], objectives[:,-1].max(), objectives[:,-1].min(), 
          median_objectives[-1], objectives_std[-1])