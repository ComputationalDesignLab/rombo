import numpy as np
import torch
from scipy.io import loadmat
from rombo.test_problems.test_problems import LangermannFunction
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# Setting data type and device for Pytorch based libraries
tkwargs = {
    "dtype": torch.float,
    "device": torch.device("cuda:0" if torch.cuda.is_available() else "cpu"),
}

n_trials = 20
n_init = 50
n_iterations = 250
mc_samples = 32

# Plotting the objective function history
plt.rcParams['font.size'] = 18
fig, ax = plt.subplots(2,1,figsize=(12,12))
iter = np.arange(1,n_iterations+1,1)
#iter = np.arange(1,26,1)
color_list = ['darkorange', 'red', 'maroon']
labels = ['BO+Log EI','ROMBO+Log EI','PODBO+Log EI']
fill_color = ['darkorange', 'red', 'maroon']
dict = {0:60,1:600}
for j in range(2):
    objective = LangermannFunction(input_dim=16, output_dim=dict[j], normalized=True)

    boei_objectives = np.zeros((n_trials, n_iterations))
    bologei_objectives = np.zeros((n_trials, n_iterations))
    romboei_objectives = np.zeros((n_trials, n_iterations))
    rombologei_objectives = np.zeros((n_trials, n_iterations))
    podboei_objectives = np.zeros((n_trials, n_iterations))
    podbologei_objectives = np.zeros((n_trials, n_iterations))
    ibnnei_objectives = np.zeros((n_trials, n_iterations))
    ibnnlogei_objectives = np.zeros((n_trials, n_iterations))

    boei_dvs = np.zeros((n_trials, n_iterations))
    bologei_dvs = np.zeros((n_trials, n_iterations))
    romboei_dvs = np.zeros((n_trials, n_iterations))
    rombologei_dvs = np.zeros((n_trials, n_iterations))
    podboei_dvs = np.zeros((n_trials, n_iterations))
    podbologei_dvs = np.zeros((n_trials, n_iterations))
    ibnnei_dvs = np.zeros((n_trials, n_iterations))
    ibnnlogei_dvs = np.zeros((n_trials, n_iterations))

    boei_t = np.zeros((n_trials, n_iterations))
    bologei_t = np.zeros((n_trials, n_iterations))
    romboei_t = np.zeros((n_trials, n_iterations))
    rombologei_t = np.zeros((n_trials, n_iterations))
    podboei_t = np.zeros((n_trials, n_iterations))
    podbologei_t = np.zeros((n_trials, n_iterations))
    ibnnei_t = np.zeros((n_trials, n_iterations))
    ibnnlogei_t = np.zeros((n_trials, n_iterations))

    boei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
    bologei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
    romboei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
    rombologei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
    podboei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
    podbologei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
    ibnnei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))
    ibnnlogei_doe = np.zeros((n_trials, n_iterations+n_init, objective.input_dim))

    for trial in range(n_trials):

        data = loadmat('./LANGERMANN/langermann_{}/BO/langermann_results_{}_{}_BOLogEI_trial_{}_LD_2_MC_32.mat'.format(objective.output_dim,objective.input_dim,objective.output_dim,trial+1))
        if dict[j]==60:
            bologei_data = data['BO_EI']
        else:
            bologei_data = data['BO_LOGEI']
        
        bologei_objectives[trial] = bologei_data['objectives'][0][0][:,:n_iterations]
        bologei_dvs[trial] = bologei_data['design'][0][0][:,:n_iterations]
        #bologei_doe[trial] = bologei_data['doe'][0][0][0][:,:n_iterations]
        bologei_t[trial] = bologei_data['time'][0][0][:,:n_iterations]

    # for trial in range(n_trials):

    #     data = loadmat('./LANGERMANN/langermann_{}/IBNN/langermann_results_{}_{}_IBNN_trial_{}_LD_2_MC_32.mat'.format(objective.output_dim,objective.input_dim,objective.output_dim,trial+1))
        
    #     ibnnlogei_data = data['BO_EI']
    #     ibnnlogei_objectives[trial] = ibnnlogei_data['objectives'][0][0][:,:n_iterations]
    #     ibnnlogei_dvs[trial] = ibnnlogei_data['design'][0][0][:,:n_iterations]
    #     #ibnnlogei_doe[trial] = ibnnlogei_data['doe'][0][0][0][:,:n_iterations]
    #     ibnnlogei_t[trial] = ibnnlogei_data['time'][0][0][:,:n_iterations]

    for trial in range(n_trials):

        data = loadmat('./LANGERMANN/langermann_{}/ROMBO/langermann_results_{}_{}_ROMBO_trial_{}_LD_2_MC_32.mat'.format(objective.output_dim,objective.input_dim,objective.output_dim,trial+1))

        rombologei_data = data['ROMBO_LOGEI']
        rombologei_objectives[trial] = rombologei_data['objectives'][0][0]
        rombologei_dvs[trial] = rombologei_data['design'][0][0]
        #rombologei_doe[trial] = rombologei_data['doe'][0][0][0]
        rombologei_t[trial] = rombologei_data['time'][0][0]

    for trial in range(n_trials):

        data = loadmat('./LANGERMANN/langermann_{}/PODBO/langermann_results_{}_{}_POD_BO_trial_{}_MC_32.mat'.format(objective.output_dim,objective.input_dim,objective.output_dim,trial+1))

        podbologei_data = data['ROMBO_LOGEI']
        podbologei_objectives[trial] = podbologei_data['objectives'][0][0]
        podbologei_dvs[trial] = podbologei_data['design'][0][0]
        #rombologei_doe[trial] = rombologei_data['doe'][0][0][0]
        podbologei_t[trial] = podbologei_data['time'][0][0]

    data_list = [bologei_objectives, rombologei_objectives, podbologei_objectives]
    #data_list = [bologei_t, rombologei_t, podbologei_t]

    i = 0
    for data in data_list:
        
        # Calculating statistics of objectives and design variables for optimization
        objectives = np.log10(data)
        mean_objectives = objectives.mean(axis = 0)
        objectives_std = objectives.std(axis = 0)/np.sqrt(n_trials)

        lower_objectives = mean_objectives - objectives_std
        upper_objectives = mean_objectives + objectives_std
        
        #lower_objectives[lower_objectives < 1e-3] = 1e-1

        #ax.fill_between(iter, lower_objectives, upper_objectives, color = fill_color[i], alpha=0.4, zorder=100)
        #plt.errorbar(iter, mean_objectives, yerr=objectives_std, capsize=5, color=color_list[i])
        #ax.plot(iter, mean_objectives, color_list[i], label = labels[i], linewidth=2)
        ax[j].errorbar(iter, mean_objectives, yerr=1.96*objectives_std,
                    color=color_list[i],     # Line color
                    ecolor=fill_color[i],    # Error bar color
                    capsize=3, capthick=1,   # Cap style
                    alpha=0.5,
                    label=labels[i], linewidth=3)
        
        i+=1

    ax[j].grid()
    ax[j].set_ylabel('Log($f_c^*$)')
    #ax[j].set_ylabel('Time Cost (s)')
    ax[j].set_xlim([1,n_iterations])
    ax[j].set_title('{} outputs'.format(dict[j]), rotation=-90, x=1.05, y=0.5, verticalalignment='center', fontweight='bold')
#ax.set_ylim([-1.3,3.0])
#ax.set_aspect(0.5)
ax[0].legend(bbox_to_anchor=(0.5, 1.0), loc='lower center', ncol=3)
ax[0].tick_params(labelbottom=False)
#handles, labels = ax[0].get_legend_handles_labels()
#fig.legend(handles, labels, loc='center right', bbox_to_anchor=(1.2, 0.5), ncol=1)
ax[1].set_xlabel('Iteration')
plt.tight_layout()
plt.savefig('langermann_objectives.pdf')
plt.show()

# Finding the best trial and corresponding design variables
# trial_idx = [boei_objectives[:,-1].argmax(), romboei_objectives[:,-1].argmax(), rombologei_objectives[:,-1].argmax(),
#              podbologei_objectives[:,-1].argmax()]

# # Plotting the contours of the function
# x_list = [boei_dvs[trial_idx[0]][-1], romboei_dvs[trial_idx[1]][-1], rombologei_dvs[trial_idx[2]][-1], podbologei_dvs[trial_idx[3]][-1]]
# x_list = [boei_doe[trial_idx[0]][int(x_list[0])], romboei_doe[trial_idx[1]][int(x_list[1])], rombologei_doe[trial_idx[2]][int(x_list[2])], podbologei_doe[trial_idx[3]][int(x_list[3])]]
# x_list = torch.tensor(x_list, **tkwargs)
# color_list = ['b', 'r', 'r', 'm']
# label_list = ['BO + EI', 'ROMBO + EI', 'ROMBO + Log EI', 'PODBO + Log EI']
# linestyle_list = ['-', '-', '--', '--']
# objective.optresult_plotter(x_list, color_list, label_list, linestyle_list, filename='emf_{}_{}_contours.pdf'.format(objective.input_dim, mc_samples))

# Printing the best objective values
print("Statistics of objective values")
print("Name: Average Best Worst Median SE")
for i in range(len(data_list)):
    objectives = np.log10(data_list[i]) #np.log10(-data)
    mean_objectives = objectives.mean(axis = 0)
    median_objectives = np.median(objectives, axis = 0) # Check calculation of the median and standard error
    objectives_std = objectives.std(axis = 0)/np.sqrt(n_trials)
    print(labels[i],':',mean_objectives[-1], objectives[:,-1].max(), objectives[:,-1].min(), 
          median_objectives[-1], objectives_std[-1])

# # Generating the nonlinear ROM model
# autoencoder = MLPAutoEnc(high_dim=objective.output_dim, hidden_dims=[128,64], zd = 10, activation = torch.nn.SiLU())
# rom = AUTOENCROM(romboei_data['xdoe'][0][0], romboei_data['ydoe'][0][0], autoencoder = autoencoder, low_dim_model = KroneckerMultiTaskGP, low_dim_likelihood = ExactMarginalLogLikelihood)
# rom.trainROM(verbose=False)

# model_list = [rom]
# color_list = ['r']
# label_list = ['Autoencoder ROM']
# objective.prediction_plotter(x_list[2].unsqueeze(0), model_list, color_list, label_list)

